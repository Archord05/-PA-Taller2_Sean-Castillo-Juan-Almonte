package Utils;

import Services.ISistemaGestorDeMazo;
import Services.SistemaGestorDeMazo;

public class Instalador {
    private ISistemaGestorDeMazo instaladorMazos;

    public Instalador() {
this.instaladorMazos =new SistemaGestorDeMazo();
    }
    public ISistemaGestorDeMazo instalarSistema(){

return this.instaladorMazos;
    }

}
