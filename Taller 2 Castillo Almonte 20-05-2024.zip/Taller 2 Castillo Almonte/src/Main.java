import Services.ISistemaGestorDeMazo;
import Utils.Instalador;
import ucn.StdIn;
import ucn.StdOut;

// se crearon todas las clases y algunos de su metodos
//se creo el isntalador pero invocarlo funciona raro
//se creo la interface
//se creo el sistema pero sin ningun metodo
//se crearon los menu principales pero sin coneciones
//TODO
//terminar los metodos inconclusos de las clases
//crear la lectura de archivos sinceramente me dio flojera y quiero descansar, llegue tarde a mi casa por arreglar pc
//crear la metodologia de sistemaGestor
//conectar los menus ya que falla algo
//adaptar del taller anterior los metodos de credenciales ya que son los mismos para este taller
//hacer validacion
//agregar mas masos soy todo oidos con ideas

public class Main {
    public static void main(String[] args) {

        ISistemaGestorDeMazo instaladorMazo= new Instalador().instalarSistema();
        menuInicio(instaladorMazo);
    }
public static void menuInicio(ISistemaGestorDeMazo instaladorMazo){

        while(true) {
    StdOut.println("╔══════════════════════════════════╗");
    StdOut.println("║     Bienvenido al deck builder   ║");
    StdOut.println("╚══════════════════════════════════╝");
    StdOut.println("╔══════════════════════════════════╗");
    StdOut.println("║         ¿Qué deseas hacer?       ║");
    StdOut.println("║       1. Iniciar sesión          ║");
    StdOut.println("║       2. Registrarse             ║");
    StdOut.println("║       3. Salir                   ║");
    StdOut.println("╚══════════════════════════════════╝");
    String opcion= StdIn.readString();
    switch (opcion){
        case "1":iniciarSecion(instaladorMazo);
        case "2":registrarse(instaladorMazo);
        case "3":break;
        case "4":buscarCarta(instaladorMazo);
        case "5":buscarTierra(instaladorMazo);
        default:StdOut.println("Ingrese opcion valida"); menuInicio(instaladorMazo);
    }
}

}
public static void iniciarSecion(ISistemaGestorDeMazo instaladorMazo){
    System.out.println("Ingrese sus datos porfavor");
    System.out.print("Usuario: ");
    String nombreUsuario = StdIn.readLine();
    System.out.print("Contrasenia :");
    String contrasenia = StdIn.readLine();
    if (!instaladorMazo.iniciarSesion(nombreUsuario, contrasenia)){
        menuInicio(instaladorMazo);
    }
    System.out.println("Hola denuevo " + nombreUsuario);
    menuPrincipal(instaladorMazo);
}
    public static void registrarse(ISistemaGestorDeMazo instaladorMazo){
        System.out.println("Ingrese sus datos porfavor");
        System.out.print("Usuario: ");
        String nombreUsuario = StdIn.readLine();
        System.out.print("Contrasenia :");
        String contrasenia = StdIn.readLine();
        instaladorMazo.registrarUsuario(nombreUsuario, contrasenia);
        System.out.println("Gracias por registrarse " + nombreUsuario);
        menuPrincipal(instaladorMazo);
    }
    public static void menuPrincipal(ISistemaGestorDeMazo instaladorMazo){
        StdOut.println("╔══════════════════════════════════╗");
        StdOut.println("║    Menu de construccion          ║");
        StdOut.println("╚══════════════════════════════════╝");
        StdOut.println("╔══════════════════════════════════╗");
        StdOut.println("║         ¿Qué deseas hacer?       ║");
        StdOut.println("║       1. Construir el mazo       ║");
        StdOut.println("║       2. ver mis mazos           ║");
        StdOut.println("║       3. Buscar Carta            ║");
        StdOut.println("║       4. Buscar Tierra           ║");
        StdOut.println("║       5. Salir                   ║");
        StdOut.println("╚══════════════════════════════════╝");
        String opcion= StdIn.readString();
        switch (opcion){
            case "1":construirMazo(instaladorMazo);
            case "2":verMazos(instaladorMazo);
            case "3":buscarCarta(instaladorMazo);
            case "4":buscarTierra(instaladorMazo);
            case "5":menuInicio(instaladorMazo);
            default:StdOut.println("Ingrese opcion valida");
        }
    }
    public static void menuConstruirMazo(ISistemaGestorDeMazo instaladorMazo){
        StdOut.println("╔══════════════════════════════════╗");
        StdOut.println("║  Menu de construccion de Mazos   ║");
        StdOut.println("╚══════════════════════════════════╝");
        StdOut.println("╔══════════════════════════════════╗");
        StdOut.println("║       ¿Ingrese una opcion?       ║");
        StdOut.println("║       1. Crear mazo nuevo        ║");
        StdOut.println("║       2. Modificar uno existente ║");
        StdOut.println("║       3. volver                  ║");
        StdOut.println("╚══════════════════════════════════╝");

        String opcion= StdIn.readString();
        switch (opcion){
            case "1":construirMazo(instaladorMazo);
            case "2":construirMazo(instaladorMazo);
            case "3":menuPrincipal(instaladorMazo);
            default:StdOut.println("Ingrese opcion valida");
        }
    }

    public static void construirMazo(ISistemaGestorDeMazo instaladorMazo){
        StdOut.println("╔══════════════════════════════════╗");
        StdOut.println("║  Menu de construccion de Mazos   ║");
        StdOut.println("╚══════════════════════════════════╝");
        StdOut.println("╔══════════════════════════════════╗");
        StdOut.println("║       ¿Ingrese una opcion?       ║");
        StdOut.println("║       1. Añadir carta            ║");
        StdOut.println("║       2. Eliminar Carta          ║");
        StdOut.println("║       3. Buscar Carta            ║");
        StdOut.println("║       4. Modificar sideboard     ║");
        StdOut.println("║       5. volver                  ║");
        StdOut.println("╚══════════════════════════════════╝");

        String opcion= StdIn.readString();
        switch (opcion){
            case "1":construirMazo(instaladorMazo);
            case "2":verMazos(instaladorMazo);
            case "3":buscarCarta(instaladorMazo);
            case "4":menuInicio(instaladorMazo);
            case "5":menuConstruirMazo(instaladorMazo);
            default:StdOut.println("Ingrese opcion valida");
        }
    }
    public static void verMazos(ISistemaGestorDeMazo instaladorMazo){
        StdOut.println("╔══════════════════════════════════╗");
        StdOut.println("║            Lista de mazos        ║"); //ni idea como agregar mas mazos
        StdOut.println("╚══════════════════════════════════╝");
        StdOut.println("╔══════════════════════════════════╗");
        StdOut.println("║       ¿Ingrese una opcion?       ║");
        StdOut.println("║       1. Mazo 1                  ║");
        StdOut.println("║       5. volver                  ║");
        StdOut.println("╚══════════════════════════════════╝");

        String opcion= StdIn.readString();

    }
    public static void buscarCarta(ISistemaGestorDeMazo instaladorMazo){

        StdOut.println("╔══════════════════════════════════╗");
        StdOut.println("║  Ingrese la carta buscada        ║");
        StdOut.println("╚══════════════════════════════════╝");
        String cardName = StdIn.readLine();
        String imprimir = instaladorMazo.imprimirCarta(cardName);
        System.out.println(imprimir);
        construirMazo(instaladorMazo);
    }

    public static void buscarTierra(ISistemaGestorDeMazo instaladorMazo){
        StdOut.println("╔═══════════════════════════════════╗");
        StdOut.println("║     Ingrese la Tierra buscada     ║");
        StdOut.println("╚═══════════════════════════════════╝");
        String landCardName = StdIn.readLine();
        String imprimir = instaladorMazo.imprimirtTierra(landCardName);
        System.out.println(imprimir);
        construirMazo(instaladorMazo);
    }
}