package Services;

import Model.*;
import ucn.ArchivoEntrada;
import ucn.ArchivoSalida;
import ucn.Registro;

import java.io.IOException;

public class SistemaGestorDeMazo implements ISistemaGestorDeMazo {
    String landList = "Land_List.txt";
    String cardList = "Card_List_txt.txt";

    private ListaCarta listaCarta;
    private ListaMazo listaMazo;
    private ListaUsuario listaUsuario;
    private ListaTierra listaTierra;
    public SistemaGestorDeMazo() {
        this.listaCarta = new ListaCarta(99);
        this.listaUsuario = new ListaUsuario(99);
        this.listaMazo = new ListaMazo(99);
        this.listaTierra = new ListaTierra(999);
    }

    @Override
    public boolean registrarUsuario(String nombreUsuario, String contrasenia) {
        return listaUsuario.agregarUsuario(new Usuario(nombreUsuario, contrasenia));
    }

    @Override
    public boolean iniciarSesion(String nombreUsuario, String contrasenia) {
        Usuario usuario;
        for (int i = 0; i < this.listaUsuario.getCantidadActual(); i++) {
            usuario = listaUsuario.obtenerPosicion(i);
            if (usuario.getNombreUsuario().equals(nombreUsuario)){
                System.out.println("Bienvenido: " + nombreUsuario);
                if (usuario.getContrasenia().equals(contrasenia)){
                    System.out.println("Logeo exitoso Bienvenido");
                    return true;
                }
            }
        }
        System.out.println("Error en el nombre de usuario o contrasenia. Intente nuevamente");
        return false;
    }

    @Override
    public boolean lecturaListaCartas() throws IOException {
        ArchivoEntrada archivoEntrada = new ArchivoEntrada(cardList);

        while (!archivoEntrada.isEndFile()){
            Registro registro = archivoEntrada.getRegistro();
            String cardName = registro.getString();
            String description = registro.getString();
            String manaCost = registro.getString();
            String type = registro.getString();
            int power = registro.getInt();
            int toughness = registro.getInt();
            int castingCost = registro.getInt();
            Carta2 carta = new Carta2(cardName, description, manaCost, type, power, toughness, castingCost);
            this.listaCarta.agregarCarta(carta);
        }
        archivoEntrada.close();
        return true;
    }

    @Override
    public boolean lecturaListaTierras() throws IOException {
        ArchivoEntrada archivoEntrada = new ArchivoEntrada(landList);

        while (!archivoEntrada.isEndFile()){
            Registro registro = archivoEntrada.getRegistro();
            String landCardName = registro.getString();
            String type = registro.getString();
            String color = registro.getString();
            Tierra2 tierra = new Tierra2(landCardName, type, color);
            this.listaTierra.agregarTierra(tierra);
        }
        archivoEntrada.close();
        return true;
    }

    //No me acuerdo si lo solicitaban, se puede utilizar la misma estructura para la salida de mazos.
    //Guarda las instancias de la listaUsuario y las escribe dentro de un documento de texto el cual queda dentro de
    //la carpeta del archivo
    @Override
    public boolean guardarRegistroUsuario() throws IOException {

        ArchivoSalida archivoSalida = new ArchivoSalida("UsuariosRegistrados.txt");
        for (int i = 0; i < listaUsuario.getCantidadActual(); i++) {
            Registro registro = new Registro(2);
            registro.agregarCampo(listaUsuario.obtenerPosicion(i).getNombreUsuario());
            registro.agregarCampo(listaUsuario.obtenerPosicion(i).getContrasenia());

            archivoSalida.writeRegistro(registro);
        }
        archivoSalida.close();
        return true;
    }

    //Prueba a usar la metodoliga de registrar usuario
    @Override
    public void construirMazo() {

    }

    @Override
    public void exportarMazo() {

    }

    @Override
    public void agregarSliboard() {

    }

    @Override
    public void modificarSlidboard() {

    }

    @Override
    public void exportarSlidboard() {

    }

    //obtener posición es nulo por alguno motivo
    @Override
    public String imprimirCarta(String CardName) {
        String imprimir = "";
        try {
            for (int i = 0; i < 52; i++) {
                if (this.listaCarta.obtenerPoscion(i).getCardname().equalsIgnoreCase(CardName)) {
                    imprimir = this.listaCarta.obtenerPoscion(i).empaquetarInformacion();
                }
            }
        } catch (Exception exception){
            System.out.println("Porfavor ingrese una carta valida");
        }
        return imprimir;
    }

    //Obtenerposición es nulo por algun motivo
    @Override
    public String imprimirtTierra(String landCardName) {
        String imprimir = "";
        try {
            for (int i = 0; i < 328; i++) {
                if (this.listaTierra.obtenerPoscion(i).getLandCardName().equalsIgnoreCase(landCardName)) {
                    imprimir = this.listaTierra.obtenerPoscion(i).empaquetarInformacionTierra();
                }
            }
        } catch (Exception exception){
           System.out.println("Porfavor ingrese una tierra valida");
        }
        return imprimir;
    }
}

// Otra opción de busqueda clase n10
// la utilize en el inicio de sesión
// prueba a usarla para las impresiones de una carta especifica.
// quizas funciona

//    @Override
//    public String buscarPorRUT(String rut) {
//        if (estaVacia()) {
//            return "La lista esta vacia";
//        }
//
//        Persona persona;
//
//        for (int i = 0; i < this.listaPersonas.getCantidadActual(); i++) {
//            persona = this.listaPersonas.obtenerPersona(i);
//
//            if (persona.getRut().equalsIgnoreCase(rut)) {
//                return persona.exponerInformacion();
//            }
//        }
//
//        return "No se encuentra una persona en el sistema con el rut indicado";
//    }