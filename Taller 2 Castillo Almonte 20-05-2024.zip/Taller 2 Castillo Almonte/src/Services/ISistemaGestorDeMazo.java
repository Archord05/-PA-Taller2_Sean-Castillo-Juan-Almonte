package Services;

import java.io.IOException;

public interface ISistemaGestorDeMazo {

    boolean  registrarUsuario(String nombreUsuario, String contrasenia);
    boolean iniciarSesion(String nombreUsuario, String contrasenia);
    boolean  lecturaListaCartas() throws IOException;
    boolean  lecturaListaTierras() throws IOException;
    boolean  guardarRegistroUsuario() throws IOException;
    void  construirMazo();
    void  exportarMazo();
    void  agregarSliboard();
    void  modificarSlidboard();
    void  exportarSlidboard();
    String  imprimirCarta(String cardName);
    String imprimirtTierra(String landCardName);




}
