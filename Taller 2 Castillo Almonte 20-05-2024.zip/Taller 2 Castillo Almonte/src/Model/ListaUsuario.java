package Model;
import ucn.*;
public class ListaUsuario {
    private Usuario[] listaUsuario;
    private int cantidadMaxima;
    private int cantidadActual;

    public ListaUsuario(int cantidadMaxima) {
        this.cantidadMaxima = cantidadMaxima;
        this.listaUsuario=new Usuario[this.cantidadMaxima];
        this.cantidadActual=0;
    }
    public int buscarPosicionNombre(String nombre){
        for (int i = 0; i <this.cantidadActual ; i++) {
            if(this.listaUsuario[i].getNombreUsuario().equals(nombre)){
                return i;
            }
        }
        return -1;
    }
    public int buscarPosicionContraseña(String contrasena,int posicion) {
            if(this.listaUsuario[posicion].getContrasenia().equals(contrasena)){
                return posicion;
            }

        return -1;
    }
    public Usuario obtenerPosicion(int posicion){
        if(posicion>cantidadActual||posicion<0){
            StdOut.println("Ingrese una posicion valida");

        }
        return this.listaUsuario[posicion];
    }
    public boolean agregarUsuario(Usuario usuario){
        this.listaUsuario[this.cantidadActual]=usuario;
        this.cantidadActual++;
        return true;
    }

    public Usuario[] getListaUsuario() {
        return listaUsuario;
    }

    public int getCantidadMaxima() {
        return cantidadMaxima;
    }

    public int getCantidadActual() {
        return cantidadActual;
    }
}
