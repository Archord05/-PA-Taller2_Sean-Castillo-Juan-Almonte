package Model;

public class Mazo extends Carta {
    private String nombreDelMazo;
    private int cantidadDeCartas;

    public Mazo(String cardname, String description, String manaCost, String type, int power, int tougness, int castingCost, String nombreDelMazo, int cantidadDeCartas) {
        super(cardname, description, manaCost, type, power, tougness, castingCost);
        this.nombreDelMazo = nombreDelMazo;
        this.cantidadDeCartas = cantidadDeCartas;
    }

    public String getNombreDelMazo() {
        return nombreDelMazo;
    }

    public int getCantidadDeCartas() {
        return cantidadDeCartas;
    }

    public void setNombreDelMazo(String nombreDelMazo) {
        this.nombreDelMazo = nombreDelMazo;
    }

    public void setCantidadDeCartas(int cantidadDeCartas) {
        this.cantidadDeCartas = cantidadDeCartas;
    }

    @Override
    public String empaquetarInformacion() {
        return this.nombreDelMazo + "n\""
                + this.cantidadDeCartas + "n\""
                + this.getCardname() + "n\""
                + this.getDescription() + "n\""
                + this.getManaCost() + "n\""
                + this.getType() + "n\""
                + this.getPower() + "n\""
                + this.getToughness() + "n\""
                + this.getCastingCost();
    }

}
