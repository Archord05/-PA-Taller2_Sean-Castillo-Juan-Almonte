package Model;

public class ListaMazo {

    private  Mazo[] listaMazo;
    private int cantidadMaxima;
    private int cantidadActual;

    public ListaMazo(int cantidadMaxima) {
        this.cantidadMaxima = cantidadMaxima;
        this.listaMazo=new Mazo[this.cantidadMaxima];
        this.cantidadActual = 0;
    }
    public int buscarPosicion(String nombreMazo){
        for (int i = 0; i <this.cantidadActual ; i++) {
            if(this.listaMazo[i].getCardname().equalsIgnoreCase(nombreMazo)){
                return i;
            }
        }
        return -1;
    }
    public Mazo obtenerPoscion(int posicion){
        return this.listaMazo[posicion];
    }
    public boolean agregarMazo(Mazo nuevoMazo){
        this.listaMazo[this.cantidadActual] = nuevoMazo;
        return true;
    }
    public boolean eliminarCarta(Mazo mazo){
        //TODO
        return false;
    }

//+ ListaMazo(cantidadMaxima; int)
    //+ buscarPosicion(nombreMazo; String); int
    //+ obtenerPosicion(posicion; int); Carta
    //+ agregarMazo(mazo; Mazo); boolean
    //+ eliminarMazo(mazo; Mazo); boolean
    //}
}
