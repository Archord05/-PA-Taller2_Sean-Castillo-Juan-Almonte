package Services;

import Model.*;
import ucn.*;

import java.io.IOException;

public class SistemaGestorDeMazo implements ISistemaGestorDeMazo {
    String landList = "Land_List.txt";
    String cardList = "Card_List_txt.txt";
    private String usuarioActual;
    private String mazoReferencia;
    private ListaCarta listaCarta;
    private ListaMazo listaMazo;
    private ListaMazo listaMazo2;
    private ListaMazo listaMazo3;
    private ListaMazo listaMazo4;
    private ListaUsuario listaUsuario;
    private ListaTierra listaTierra;

    public SistemaGestorDeMazo() throws IOException {
        this.listaCarta = new ListaCarta(999);
        this.listaUsuario = new ListaUsuario(999);
        this.listaMazo = new ListaMazo(999);
        this.listaMazo2 = new ListaMazo(999);
        this.listaMazo3 = new ListaMazo(999);
        this.listaMazo4 = new ListaMazo(999);
        this.listaTierra = new ListaTierra(999);
        lecturaListaCartas();
        lecturaListaTierras();
    }

    @Override
    public boolean registrarUsuario(String nombreUsuario, String contrasenia) {
        return listaUsuario.agregarUsuario(new Usuario(nombreUsuario, contrasenia,0,0,0,0));
    }

    @Override
    public boolean iniciarSesion(String nombreUsuario, String contrasenia) {
        Usuario usuario;
        for (int i = 0; i < this.listaUsuario.getCantidadActual(); i++) {
            usuario = listaUsuario.obtenerPosicion(i);
            if (usuario.getNombreUsuario().equals(nombreUsuario)) {
                System.out.println("Bienvenido: " + nombreUsuario);
                if (usuario.getContrasenia().equals(contrasenia)) {
                    System.out.println("Logeo exitoso Bienvenido");
                    this.usuarioActual = nombreUsuario;
                    return true;
                }
            }
        }
        if (this.listaUsuario.Esvacio()) {
            System.out.println(" Intente mas tarde,No hay usuarios registrados");
            return false;

        }
        System.out.println("Error en el nombre de usuario o contrasenia. Intente nuevamente");
        return false;
    }

    @Override
    public boolean lecturaListaCartas() throws IOException {
        In archivoEntrada = new In(cardList);

        while (!archivoEntrada.isEmpty()) {
            String[] registro = archivoEntrada.readLine().split(";");
            if (!registro[0].equalsIgnoreCase("cardname")) {
                String cardName = registro[0];
                String description = registro[1];
                String manaCost = registro[2];
                String type = registro[3];
                int power = Integer.parseInt(registro[4]);
                int toughness = Integer.parseInt(registro[5]);
                int castingCost = Integer.parseInt(registro[6]);
                Carta2 carta = new Carta2(cardName, description, manaCost, type, power, toughness, castingCost);
                this.listaCarta.agregarCarta(carta);
            }
        }
        archivoEntrada.close();
        return true;
    }


    @Override
    public boolean lecturaListaTierras() throws IOException {
        ArchivoEntrada archivoEntrada = new ArchivoEntrada(landList);

        while (!archivoEntrada.isEndFile()) {
            Registro registro = archivoEntrada.getRegistro();
            String landCardName = registro.getString();
            String type = registro.getString();
            String color = registro.getString();
            Tierra2 tierra = new Tierra2(landCardName, type, color);
            this.listaTierra.agregarTierra(tierra);
        }
        archivoEntrada.close();
        return true;
    }

    //No me acuerdo si lo solicitaban, se puede utilizar la misma estructura para la salida de mazos.
    //Guarda las instancias de la listaUsuario y las escribe dentro de un documento de texto el cual queda dentro de
    //la carpeta del archivo
    @Override
    public boolean guardarRegistroUsuario() throws IOException {

        ArchivoSalida archivoSalida = new ArchivoSalida("UsuariosRegistrados.txt");
        for (int i = 0; i < listaUsuario.getCantidadActual(); i++) {
            Registro registro = new Registro(2);
            registro.agregarCampo(listaUsuario.obtenerPosicion(i).getNombreUsuario());
            registro.agregarCampo(listaUsuario.obtenerPosicion(i).getContrasenia());

            archivoSalida.writeRegistro(registro);
        }
        archivoSalida.close();
        return true;
    }

    @Override
    public boolean eliminarCarta(String carta) {
        int cantidad = 0; //25-05-2024 La variable cantidad se declara afuera para usar el try catch
        boolean EsTierra = false;
        boolean eliminar = true;
        if (!imprimirCarta(carta).equalsIgnoreCase("") || !imprimirtTierra(carta).equalsIgnoreCase("")) {
            StdOut.println("Carta encontrada en el sistema");
            StdOut.println("Ingrese el número de copias que desea eliminar");
            try {
                cantidad = StdIn.readInt(); //25-05-2024 Si la cantidad no es de tipo entera se atrapa la excepción
            } catch (Exception InputMismatchException) {
                System.out.println("Ingrese un valor numérico válido. Por razones cómicas se repetirá dos veces el siguiente mensaje");
                return false;
            }
            if (!imprimirtTierra(carta).equalsIgnoreCase("")) {
                EsTierra = true;
            }

            StdOut.println("");
            StdOut.println("╔═════════════════════════════════════════════╗");
            StdOut.println("║ Ingrese el mazo del que desea eliminar cartas ║"); //ni idea cómo agregar más mazos
            StdOut.println("╚═════════════════════════════════════════════╝");
            StdOut.println("╔══════════════════════════════════╗");
            StdOut.println("║       ¿Ingrese una opción?       ║");
            StdOut.println("║       1. Mazo 1                  ║");
            StdOut.println("║       2. Mazo 2                  ║");
            StdOut.println("║       3. Mazo 3                  ║");
            StdOut.println("║       4. Mazo 4                  ║");
            StdOut.println("║       5. No eliminar carta       ║");
            StdOut.println("╚══════════════════════════════════╝");
            String opcion = StdIn.readString();
            ListaMazo listaMazoSeleccionada = null;

            switch (opcion) {
                case "1":
                    listaMazoSeleccionada = listaMazo;
                    break;
                case "2":
                    listaMazoSeleccionada = listaMazo2;
                    break;
                case "3":
                    listaMazoSeleccionada = listaMazo3;
                    break;
                case "4":
                    listaMazoSeleccionada = listaMazo4;
                    break;
                case "5":
                    return false;
                default:
                    StdOut.println("Opción inválida");
                    return false;
            }

            int respuesta = listaMazoSeleccionada.buscarPosicion(carta, usuarioActual); //los métodos funcionan, pero no es adecuado el agregar

            if (respuesta != -1) {
                Mazo mazo = listaMazoSeleccionada.modificarCantidad(listaMazoSeleccionada.obtenerPoscion(respuesta), cantidad, eliminar);
                if (mazo.getCantidadDeCartas() <= 0) {
                    listaMazoSeleccionada.eliminarCarta(mazo, usuarioActual);
                    StdOut.println("╔═══════════════════════════════════════════════╗");
                    StdOut.println("║  Carta eliminada:                             ║");
                    StdOut.println("║ " + carta + "                                      ║");
                    StdOut.println("╚═══════════════════════════════════════════════╝");
                    return true;
                }
                StdOut.println("╔═══════════════════════════════════════════════╗");
                StdOut.println("║  Se han eliminado: " + cantidad + "                        ║");
                StdOut.println("║   La cantidad actual de " + carta + " es:            ║");
                StdOut.println("║   " + mazo.getCantidadDeCartas() + "                                         ║");
                StdOut.println("╚═══════════════════════════════════════════════╝");
                return true;
            }
        }

        return false;
    }

    // Esto nomas lo deje planteado porque al final todas las exportaciones deberian ser iguales
    // se deberia pedir por parametro el nombre del mazo o en su defecto el nombre del usuario actual via el main.
    @Override
    public boolean exportarMazo() throws IOException {
        ArchivoSalida archivoSalida = new ArchivoSalida("Mazo 1");
        for (int i = 0; i < this.listaMazo.getCantidadActual(); i++) {
            Registro registro = new Registro(3);
            registro.agregarCampo(listaMazo.obtenerPoscion(i).getUsuarioActual());
            registro.agregarCampo(listaMazo.obtenerPoscion(i).getCantidadDeCartas());
            registro.agregarCampo(listaMazo.obtenerPoscion(i).getCardname());

            archivoSalida.writeRegistro(registro);
        }
        archivoSalida.close();
        return true;
    }

    @Override
    public boolean agregarSliboard(int cantidad, String carta, ListaMazo listaMazoSeleccionada, String respuesta,boolean esSideck) {
            if (respuesta.equalsIgnoreCase("sin ingresar")) {
                Sidedeck sidedeck=new Sidedeck(this.usuarioActual,cantidad,carta,this.mazoReferencia);
                Mazo aux = sidedeck;
                listaMazoSeleccionada.agregaraMazo(aux);
                StdOut.println("Dato agregado: " + aux.getCardname() + " " + aux.getCantidadDeCartas());
                return true;
            }
            if (respuesta.equalsIgnoreCase("existente")) {
                int obtenerposicion = listaMazoSeleccionada.buscarPosicion(carta, usuarioActual);
                Mazo mazo = listaMazoSeleccionada.modificarCantidad(listaMazoSeleccionada.obtenerPoscion(obtenerposicion), cantidad);
                StdOut.println(mazo.empaquetarInformacion());
                return true;
            }
            return false;
    }

    @Override
    public void modificarSlidboard() {

    }

    @Override
    public void exportarSlidboard() {

    }

    //obtener posición es nulo por alguno motivo
    @Override
    public String imprimirCarta(String CardName) {
        String imprimir = "";

        for (int i = 0; i < listaCarta.getCantidadActual(); i++) {
            if (this.listaCarta.obtenerPoscion(i).getCardname().equalsIgnoreCase(CardName)) {
                imprimir = this.listaCarta.obtenerPoscion(i).empaquetarInformacion();
                break;
            }
        }


        return imprimir;
    }

    //Obtenerposición es nulo por algun motivo
    @Override
    public String imprimirtTierra(String landCardName) {
        String imprimir = "";

        for (int i = 0; i < listaTierra.getCantidadActual(); i++) {
            if (this.listaTierra.obtenerPoscion(i).getLandCardName().equalsIgnoreCase(landCardName)) {
                imprimir = this.listaTierra.obtenerPoscion(i).empaquetarInformacionTierra();
            }
        }

        return imprimir;
    }
    //TODO:separar los metodos de validar, seleccionar, agregar
    //crear las validaciones dependiendo un booleano que me dira si es mazo nuevo o existente
    //crear un while para cambiar la opcion
    //respetar la logica anterior

    @Override
    // Método principal que llama a los métodos auxiliares
    public boolean agregarnuevaCarta(String carta, boolean origen,boolean esSidedeck) {//nombre de la carta a agregar, el booleano para diferenciar si es de menu creado o modificado
        ListaMazo listaMazoSeleccionada = null;                            //
        int posicion=this.listaUsuario.buscarPosicionNombre(this.usuarioActual);
        Usuario usuarioAConsultar=this.listaUsuario.obtenerPosicion(posicion);
        boolean EsTierra = !imprimirtTierra(carta).equalsIgnoreCase("");
        int cantidad = leerCantidadDeCopias(EsTierra);
        if (cantidad == -1) return false;

               if(!origen&&!esSidedeck) {
                   listaMazoSeleccionada = seleccionarMazo(origen);
               } else if (origen&&!esSidedeck) {
                   listaMazoSeleccionada = seleccionarMazo(usuarioAConsultar.getMazo(),usuarioAConsultar.getMazo2(),usuarioAConsultar.getMazo3(),usuarioAConsultar.getMazo4());
               }
               if (esSidedeck) {
                   listaMazoSeleccionada = seleccionarMazo(origen,esSidedeck);
               }
               if (listaMazoSeleccionada == null){
                   return false;
               }
        if(esSidedeck) {
            String respuesta = comprobarCarta(cantidad, carta, listaMazoSeleccionada, EsTierra,esSidedeck);  // aqui se comprueba
            if (!comprobarCantidadSideDeck(cantidad, listaMazoSeleccionada)) return false;

            return agregarSliboard(cantidad, carta, listaMazoSeleccionada, respuesta,esSidedeck);
        }
        String respuesta = comprobarCarta(cantidad, carta, listaMazoSeleccionada, EsTierra,esSidedeck);  // aqui se comprueba
        if (!comprobarCantidad(cantidad, listaMazoSeleccionada)) return false;

        return procesarCarta(cantidad, carta, listaMazoSeleccionada, respuesta);

    }

    // Método para leer la cantidad de copias del usuario
    private int leerCantidadDeCopias(boolean EsTierra) {
        StdOut.println("Ingrese el número de copias que desea agregar");
        int cantidad;
        try {
            cantidad = StdIn.readInt();
        } catch (Exception InputMismatchException) {
            System.out.println("Ingrese un valor numérico válido.");
            return -1;
        }

        // Mensaje de validación según el tipo de carta
        String mensaje;
        if (EsTierra) {
            mensaje = "Cantidad inválida. Ingrese una cantidad mayor a 0.";
        } else {
            mensaje = "Cantidad inválida. Ingrese una cantidad entre 1 y 4.";
        }

        // Validación del rango de la cantidad ingresada
        while (cantidad <= 0 || (!EsTierra && cantidad >= 5)) {
            StdOut.println(mensaje);
            cantidad = StdIn.readInt();
        }
        return cantidad;
    }


    // Método para seleccionar el mazo

    private ListaMazo seleccionarMazo(boolean origen,boolean Sidedeck) { //mazo sidedeck
        while (true) {
            StdOut.println("╔══════════════════════════════════════════════╗");
            StdOut.println("║ Ingrese el sidedeck que desea agregar cartas ║");
            StdOut.println("╚══════════════════════════════════════════════╝");
            StdOut.println("╔══════════════════════════════════╗");
            StdOut.println("║       ¿Ingrese una opción?       ║");
            StdOut.println("║       1. Mazo 1                  ║");
            StdOut.println("║       2. Mazo 2                  ║");
            StdOut.println("║       3. Mazo 3                  ║");
            StdOut.println("║       4. Mazo 4                  ║");
            StdOut.println("║       5. No agregar carta        ║");
            StdOut.println("╚══════════════════════════════════╝");

            String opcion = StdIn.readString();

            boolean comprobar = this.listaMazo.creoMazo(this.usuarioActual); //verifica si el el mazo se creo
            boolean comprobar2 = this.listaMazo2.creoMazo(this.usuarioActual);
            boolean comprobar3 = this.listaMazo3.creoMazo(this.usuarioActual);
            boolean comprobar4 = this.listaMazo4.creoMazo(this.usuarioActual);
            switch (opcion) {


                case "1":
                    if (comprobar) {
                        StdOut.println("error vuelva a intentarlo");
                        StdOut.println(this.usuarioActual + " no ha creado el mazo 1");
                        return null;
                    }
                   this.mazoReferencia="mazo1";
                    return listaMazo;

                case "2":
                    if (comprobar2) {
                        StdOut.println("error vuelva a intentarlo");
                        StdOut.println(this.usuarioActual + " no ha creado el mazo 2");
                        return null;
                    }
                    this.mazoReferencia="mazo2";
                    return listaMazo2;
                case "3":
                    if (comprobar3) {
                        StdOut.println("error vuelva a intentarlo");
                        StdOut.println(this.usuarioActual + " no ha creado el mazo 3");
                        return null;
                    }
                    this.mazoReferencia="mazo3";
                    return listaMazo3;
                case "4":
                    if (comprobar4) {
                        StdOut.println("error vuelva a intentarlo");
                        StdOut.println(this.usuarioActual + " no ha creado el mazo 4");
                        return null;
                    }
                    this.mazoReferencia="mazo4";
                    return listaMazo4;
                case "5":
                    return null;
                default:
                    StdOut.println("Opción inválida");
            }
        }
    }
    private ListaMazo seleccionarMazo(boolean origen) {
        StdOut.println("╔═════════════════════════════════════════════╗");
        StdOut.println("║ Ingrese el mazo que desea agregar las cartas ║");
        StdOut.println("╚═════════════════════════════════════════════╝");
        StdOut.println("╔══════════════════════════════════╗");
        StdOut.println("║       ¿Ingrese una opción?       ║");
        StdOut.println("║       1. Mazo 1                  ║");
        StdOut.println("║       2. Mazo 2                  ║");
        StdOut.println("║       3. Mazo 3                  ║");
        StdOut.println("║       4. Mazo 4                  ║");
        StdOut.println("║       5. No agregar carta        ║");
        StdOut.println("╚══════════════════════════════════╝");

        String opcion = StdIn.readString();
        if (!origen) {
            boolean comprobar = this.listaMazo.creoMazo(this.usuarioActual); //verifica si el el mazo se creo
            boolean comprobar2 = this.listaMazo2.creoMazo(this.usuarioActual);
            boolean comprobar3 = this.listaMazo3.creoMazo(this.usuarioActual);
            boolean comprobar4 = this.listaMazo4.creoMazo(this.usuarioActual);
            switch (opcion) {


                case "1":
                    if (comprobar) {
                        StdOut.println("error vuelva a intentarlo");
                        StdOut.println(this.usuarioActual + " no ha creado el mazo 1");
                        return null;
                    }
                    return listaMazo;

                case "2":
                    if (comprobar2) {
                        StdOut.println("error vuelva a intentarlo");
                        StdOut.println(this.usuarioActual + " no ha creado el mazo 2");
                        return null;
                    }
                    return listaMazo2;
                case "3":
                    if (comprobar3) {
                        StdOut.println("error vuelva a intentarlo");
                        StdOut.println(this.usuarioActual + " no ha creado el mazo 3");
                        return null;
                    }
                    return listaMazo3;
                case "4":
                    if (comprobar4) {
                        StdOut.println("error vuelva a intentarlo");
                        StdOut.println(this.usuarioActual + " no ha creado el mazo 4");
                        return null;
                    }
                    return listaMazo4;
                case "5":
                    return null;
                default:
                    StdOut.println("Opción inválida");
                    return null;
            }
        }
      return null;
    }
    private ListaMazo seleccionarMazo(int mazo, int mazo2, int mazo3, int mazo4) {
        StdOut.println("╔═════════════════════════════════════════════╗");
        StdOut.println("║ Ingrese el mazo que desea agregar las cartas ║");
        StdOut.println("╚═════════════════════════════════════════════╝");
        StdOut.println("╔══════════════════════════════════╗");
        StdOut.println("║       ¿Ingrese una opción?       ║");
        StdOut.println("║       1. Mazo 1                  ║");
        StdOut.println("║       2. Mazo 2                  ║");
        StdOut.println("║       3. Mazo 3                  ║");
        StdOut.println("║       4. Mazo 4                  ║");
        StdOut.println("║       5. No agregar carta        ║");
        StdOut.println("╚══════════════════════════════════╝");

        String opcion = StdIn.readString();

        switch (opcion) {
            case "1":
                if (mazo != 0) {
                    StdOut.println("Error, vuelva a intentarlo. " + this.usuarioActual + " ya ha creado el mazo 1");
                    return null;
                }
                return listaMazo;
            case "2":
                if (mazo2 != 0) {
                    StdOut.println("Error, vuelva a intentarlo. " + this.usuarioActual + " ya ha creado el mazo 2");
                    return null;
                }
                return listaMazo2;
            case "3":
                if (mazo3 != 0) {
                    StdOut.println("Error, vuelva a intentarlo. " + this.usuarioActual + " ya ha creado el mazo 3");
                    return null;
                }
                return listaMazo3;
            case "4":
                if (mazo4 != 0) {
                    StdOut.println("Error, vuelva a intentarlo. " + this.usuarioActual + " ya ha creado el mazo 4");
                    return null;
                }
                return listaMazo4;
            case "5":
                return null;
            default:
                StdOut.println("Opción inválida");
                return null;
        }
    }





    // Método para procesar la carta y agregarla o modificarla en el mazo
    private boolean procesarCarta(int cantidad, String carta, ListaMazo listaMazoSeleccionada, String respuesta) {
        if (respuesta.equalsIgnoreCase("sin ingresar")) {
            Mazo aux = listaMazoSeleccionada.agregarMazo(usuarioActual, cantidad, carta);
            listaMazoSeleccionada.agregaraMazo(aux);
            StdOut.println("Dato agregado: " + aux.getCardname() + " " + aux.getCantidadDeCartas());
            return true;
        }
        if (respuesta.equalsIgnoreCase("existente")) {
            int obtenerposicion = listaMazoSeleccionada.buscarPosicion(carta, usuarioActual);
            Mazo mazo = listaMazoSeleccionada.modificarCantidad(listaMazoSeleccionada.obtenerPoscion(obtenerposicion), cantidad);
            StdOut.println(mazo.empaquetarInformacion());
            return true;
        }
        return false;
    }


    @Override
public boolean comprobarListaModificada(){
    boolean comprobar=this.listaMazo.Esvacio();
    boolean comprobar2=this.listaMazo2.Esvacio();
    boolean comprobar3=this.listaMazo3.Esvacio();
    boolean comprobar4=this.listaMazo4.Esvacio();
    if(comprobar&&comprobar2&&comprobar3&&comprobar4){
    return true;
    }
        return false;
}
     public boolean comprobarCreacionMazo(){
        boolean comprobar=this.listaMazo.creoMazo(this.usuarioActual); //verifica si el el mazo se creo
        boolean comprobar2=this.listaMazo2.creoMazo(this.usuarioActual);
        boolean comprobar3=this.listaMazo3.creoMazo(this.usuarioActual);
        boolean comprobar4=this.listaMazo4.creoMazo(this.usuarioActual);
        if(!comprobar&&!comprobar2&&!comprobar3&&!comprobar4){
            return true;
        }
        return false;
    }
    public boolean comprobarMazosCreados(){
        boolean comprobar=this.listaMazo.creoMazo(this.usuarioActual);
        boolean comprobar2=this.listaMazo2.creoMazo(this.usuarioActual);
        boolean comprobar3=this.listaMazo3.creoMazo(this.usuarioActual);
        boolean comprobar4=this.listaMazo4.creoMazo(this.usuarioActual);
       int posicion=this.listaUsuario.buscarPosicionNombre(this.usuarioActual);
        if(!comprobar){
            boolean comprobacion=this.listaUsuario.comprobarMazo(comprobar,posicion,1);
        }
        if(!comprobar2){
            boolean comprobacion=this.listaUsuario.comprobarMazo(comprobar,posicion,2);
        }
        if(!comprobar3){
            boolean comprobacion=this.listaUsuario.comprobarMazo(comprobar,posicion,3);
        }
        if(!comprobar4){
            boolean comprobacion=this.listaUsuario.comprobarMazo(comprobar,posicion,4);
        }
        if(comprobar){
            boolean comprobacion=this.listaUsuario.comprobarMazo(comprobar,posicion,1);
        }
        if(comprobar2){
            boolean comprobacion=this.listaUsuario.comprobarMazo(comprobar,posicion,2);
        }
        if(comprobar3){
            boolean comprobacion=this.listaUsuario.comprobarMazo(comprobar,posicion,3);
        }
        if(comprobar4){
            boolean comprobacion=this.listaUsuario.comprobarMazo(comprobar,posicion,4);
        }
        return true;
    }

    public  String comprobarCarta(int cantidad, String carta, ListaMazo listaMazoseleccioada, boolean Estierra,boolean esSidedeck){   //metodo para comprobar si el limete de carta no fue superado
        int comprobar= listaMazoseleccioada.buscarPosicion(carta,usuarioActual);          // no es necesario comprobar si el dato no ha sido ingresado
        int aux;
        if(comprobar==-1){
            return "sin ingresar";
        }
        if(comprobar!=-1){                          //si se encuentra  se debe de comprobar que el dato ingresado no supere la cantidad maxima
           if(!esSidedeck) {
               Mazo comprobarcantidad = listaMazoseleccioada.obtenerPoscion(comprobar);
               aux=comprobarcantidad.getCantidadDeCartas();
           }else {
               Sidedeck comprobarCantidadSideDeck = (Sidedeck) listaMazoseleccioada.obtenerPoscion(comprobar); //revisar
               aux=comprobarCantidadSideDeck.getCantidadDeCartas();
           }

           if(aux+cantidad>=5&&!Estierra){              //metodo que comprueba que carta no supere 4
               StdOut.println("Cantidad supera el limite de cartas permitido");
               return "no valido";
           }
        }
        return "existente";                                              //se permite el ingreso
    }

    public boolean comprobarCantidadSideDeck(int cantidad,ListaMazo listaMazo){
        this.listaMazo=listaMazo;
        int acumulador=listaMazo.contar60(usuarioActual);
        if(acumulador+cantidad>15){
            StdOut.println("Cantidad de cartas en el mazo supera el limite de cartas permitido");
            return false;
        }

        return true;
    }
    public boolean comprobarCantidad(int cantidad,ListaMazo listaMazo){
    this.listaMazo=listaMazo;
    int acumulador=listaMazo.contar60(usuarioActual);
    if(acumulador+cantidad>60){
        StdOut.println("Cantidad de cartas en el mazo supera el limite de cartas permitido");
        return false;
    }

        return true;
    }
}


